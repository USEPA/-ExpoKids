vg = (function(){
